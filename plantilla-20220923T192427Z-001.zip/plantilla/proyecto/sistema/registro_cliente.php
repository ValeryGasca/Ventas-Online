<?php 
	session_start();
	if($_SESSION['rol'] != 1)
	{
		header("location: ./");
	}
	
	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['nombre']) || empty($_POST['correo']) || empty($_POST['usuario']) || empty($_POST['clave']) || empty($_POST['rol']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$nombre = $_POST['nombre'];
			$email  = $_POST['correo'];
			$user   = $_POST['usuario'];
			$clave  = md5($_POST['clave']);
			$rol    = $_POST['rol'];


			$query = mysqli_query($conection,"SELECT * FROM usuario WHERE usuario = '$user' OR correo = '$email' ");
			$result = mysqli_fetch_array($query);

			if($result > 0){
				$alert='<p class="msg_error">El correo o el usuario ya existe.</p>';
			}else{

				$query_insert = mysqli_query($conection,"INSERT INTO usuario(nombre,correo,usuario,clave,rol)
																	VALUES('$nombre','$email','$user','$clave','$rol')");
				if($query_insert){
					$alert='<p class="msg_save">Usuario creado correctamente.</p>';
				}else{
					$alert='<p class="msg_error">Error al crear el usuario.</p>';
				}

			}


		}

	}



 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Registro Usuario</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			<h1>Registro cliente</h1>
			<hr>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

			<form action="" method="post">
			    <label for="nombre">Codigo</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo">
				<label for="usuario">Tipo de Identificacion</label>
				<select>
                <option>Registro Civil</option>
                <option selected="selected">Cedula de Ciudadania</option>
                 <option>NIT</option>
                  <option>Tarjeta de Identidad</option>
                     <option>PEP</option>
</select>
				<label for="usuario">Identificacion</label>
				<input type="text" name="Identificacion" id="usuario" placeholder="Identificacion" required>
				<label for="nombre">Nombre</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo">
				<label for="nombre">apellidos</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo">
				<label for="nombre">Celular</label>
				<input type="text" name="nombre" id="nombre" placeholder="Nombre completo">
				<label for="usuario">Direccion</label>
				<input type="text" name="Direccion" id="Direccion" placeholder="Direccion" required>
				<label for="correo">Correo electrónico</label>
				<input type="email" name="correo" id="correo" placeholder="Correo electrónico">
						
				<input type="submit" value="Crear usuario" class="btn_save">
				<input type="reset" value="Limpiar Campos" class="btn_save">

			</form>


		</div>


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>