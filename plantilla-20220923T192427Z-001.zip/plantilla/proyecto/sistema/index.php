<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Sistema Ventas en linea</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	
	<section id="container">
	<hr size="8px" width="29%" color="#ffffff" >
		<h1><font color="red"> Bienvenido al sistema </font></h1>
		<hr width="29%" color="#ffffff" size="8">
	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>